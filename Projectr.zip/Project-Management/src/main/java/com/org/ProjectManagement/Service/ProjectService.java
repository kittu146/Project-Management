package com.org.ProjectManagement.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.org.ProjectManagement.Model.Project;
import com.org.ProjectManagement.Repository.ProjectRepository;

import java.util.List;
import java.util.Optional;

@Service
public class ProjectService {

    @Autowired
    private ProjectRepository projectRepository;

    public List<Project> getAllProjects() {
        return projectRepository.findAll();
    }

    public Optional<Project> getProjectById(Long id) {
        return projectRepository.findById(id);
    }

    public Project createProject(Project project) {
        return projectRepository.save(project);
    }

    public Project updateProject(Long id, Project project) {
        if (projectRepository.existsById(id)) {
            project.setId(id); // Ensure the ID is set correctly
            return projectRepository.save(project);
        }
        return null; // Or throw an exception indicating project not found
    }

    public void deleteProject(Long id) {
        projectRepository.deleteById(id);
    }
}
